import React from 'react'
import TodoForm from '../components/TodoForm'

function AddTodoPage() {
  return (
    <TodoForm/>
  )
}

export default AddTodoPage